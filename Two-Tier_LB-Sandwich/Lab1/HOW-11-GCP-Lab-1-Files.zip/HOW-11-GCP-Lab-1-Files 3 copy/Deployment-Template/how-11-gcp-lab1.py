# Libraries
from random import randint

randnum = str(randint(10, 99))

# Storage-Buckets
bootstrap_bucket = "ignite-lab1-bootstrapa"
scripts_bucket = "ignite-lab1-startup"


# service_account and sshkey, updated to use default service account
serviceaccount = "default"
sshkey = "ignite: ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDGPo/tgcCRzvI3NVCTRoqV8EhpHN4NGUSUzAs+Tkx8pZyThHbU62C1gYZdxLfY9vKSMLR06H+hjrY2MS1eC8CDrUzlBo9+7H5voN+3fx2jCo1f5TLUQAHoWBrdVCCCjBdcJEHYmHgXiOT/vSoBddC8WM12X6pYmqJTWwIGQfqxcMcUF6MP7m1C7KtLz/aqJ/s4yyALtttjCUJwgoPCnR9sa0FfJEravXYz7asIKD41IWEDptQdy0DmFrLGpf+2hune2fmZ/XSnSfesuKIT8/ESlgh++KlpwU+hkXAVhHUimGfalsVXX29nui3LP4FN+94poGp+8+577h7gSWw+GLdX ignite"


# Variables
zone = "us-central1-a"
region = "us-central1"
machineTypeFw = "n1-standard-4"
machineTypeWeb = "f1-micro"


# Script Files
webserver_script = 'webserver-startup.sh'
dbserver_script = 'dbserver-startup.sh'

#Instances
fw_instance = "panw-fw" + randnum
web_instance = "webserver" + randnum
db_instance = "dbserver" + randnum

# Source Images
imageFw = "vmseries-bundle2-810"
imageWeb = "debian-8"

# Custom VPcs and subnets
mgmt_network = "mgmt-network" + randnum
mgmt_subnet = "mgmt-subnet" + randnum
web_network = "web-network" + randnum
web_subnet = "web-subnet" + randnum
public_network = "public-network" + randnum
public_subnet = "public-subnet" + randnum
db_network = "db-network" + randnum
db_subnet = "db-subnet" + randnum

# Firewall-Rules
web_firewall = "web-firewall" + randnum
db_firewall = "db-firewall" + randnum
mgmt_firewall = "mgmt-firewall" + randnum
public_firewall = "public-firewall" + randnum

# Routes
web_route = "web-route" + randnum
db_route = "db-route" + randnum

# static_ip_configuration
# Interfaces
managemet_interface_ip = '10.5.0.4'
public_interface_ip = '10.5.1.4'
web_interface_ip = '10.5.2.4'
db_interface_ip = '10.5.3.4'

# Servers
web_server_ip = '10.5.2.5'
db_server_ip = '10.5.3.5'

# Subnets
mgmt_subnet_ip = '10.5.0.0/24'
web_subnet_ip = '10.5.2.0/24'
public_subnet_ip = '10.5.1.0/24'
db_subnet_ip = '10.5.3.0/24'

COMPUTE_URL_BASE = 'https://www.googleapis.com/compute/v1/'


def GenerateConfig(context):
    outputs = []
    resources = [
        {
            'name': fw_instance,
            'type': 'compute.v1.instance',
            'properties': {
                'zone': zone,
                'machineType': ''.join([COMPUTE_URL_BASE, 'projects/', context.env['project'],
                                        '/zones/', zone,
                                        '/machineTypes/', machineTypeFw]),
                'canIpForward': True,
                'disks': [{
                    'deviceName': 'boot',
                    'type': 'PERSISTENT',
                    'boot': True,
                    'autoDelete': True,
                    'initializeParams': {
                        'sourceImage': ''.join([COMPUTE_URL_BASE, 'projects/paloaltonetworksgcp-public/global/images/', imageFw])
                    }
                }],
                'metadata': {
                    'items': [{'key': 'vmseries-bootstrap-gce-storagebucket', 'value': bootstrap_bucket},
                              {'key': 'ssh-keys', 'value': sshkey},
                              {'key': 'serial-port-enable', 'value': '1'}]
                },
                'serviceAccounts': [{
                    'email': 'default',
                    'scopes': [
                        'https://www.googleapis.com/auth/cloud.useraccounts.readonly',
                        'https://www.googleapis.com/auth/devstorage.read_only',
                        'https://www.googleapis.com/auth/logging.write',
                        'https://www.googleapis.com/auth/monitoring.write',
                    ]}
                ],
                'networkInterfaces': [
                    {
                        'network': '$(ref.' + mgmt_network + '.selfLink)',
                        'accessConfigs': [{
                            'name': 'MGMT Access',
                            'type': 'ONE_TO_ONE_NAT'
                        }],
                        'subnetwork': '$(ref.' + mgmt_subnet + '.selfLink)',
                        'networkIP': managemet_interface_ip,
                    },
                    {
                        'network': '$(ref.' + public_network + '.selfLink)',
                        'accessConfigs': [{
                            'name': 'External access',
                            'type': 'ONE_TO_ONE_NAT'
                        }],
                        'subnetwork': '$(ref.' + public_subnet + '.selfLink)',
                        'networkIP': public_interface_ip,
                    },
                    {
                        'network': '$(ref.' + web_network + '.selfLink)',
                        'subnetwork': '$(ref.' + web_subnet + '.selfLink)',
                        'networkIP': web_interface_ip,
                    },
                    {
                        'network': '$(ref.' + db_network + '.selfLink)',
                        'subnetwork': '$(ref.' + db_subnet + '.selfLink)',
                        'networkIP': db_interface_ip,
                    }
                ]
            }
        },
        {
            'name': db_instance,
            'type': 'compute.v1.instance',
            'properties': {
                'zone': zone,
                'machineType': ''.join([COMPUTE_URL_BASE, 'projects/', context.env["project"],
                                        '/zones/', zone,
                                        '/machineTypes/', machineTypeWeb]),
                'disks': [{
                    'deviceName': 'boot',
                    'type': 'PERSISTENT',
                    'boot': True,
                    'autoDelete': True,
                    'initializeParams': {
                        'sourceImage': ''.join([COMPUTE_URL_BASE, 'projects/',
                                                'debian-cloud', '/global/',
                                                'images/', 'family/', imageWeb])
                    }
                }],
                'metadata': {
                    'dependsOn': [fw_instance],
                    'items': [{
                        'key': 'startup-script-url',
                        'value': ''.join(['gs://',scripts_bucket,'/',dbserver_script])},
                        {'key': 'ssh-keys', 'value': sshkey},
                        {'key': 'serial-port-enable', 'value': '1'}
                    ]
                },
                'serviceAccounts': [{
                    'email': 'default',
                    'scopes': [
                        'https://www.googleapis.com/auth/cloud.useraccounts.readonly',
                        'https://www.googleapis.com/auth/devstorage.read_only',
                        'https://www.googleapis.com/auth/logging.write',
                        'https://www.googleapis.com/auth/monitoring.write',
                        'https://www.googleapis.com/auth/compute.readonly',
                    ]}
                ],
                'networkInterfaces': [{
                    'network': '$(ref.' + db_network + '.selfLink)',
                    'subnetwork': '$(ref.' + db_subnet + '.selfLink)',
                    'networkIP': db_server_ip
                }]
            }
        },
        {
            'name': web_instance,
            'type': 'compute.v1.instance',
            'properties': {
                'zone': zone,
                'machineType': ''.join([COMPUTE_URL_BASE, 'projects/', context.env["project"],
                                        '/zones/', zone,
                                        '/machineTypes/', machineTypeWeb]),
                'disks': [{
                    'deviceName': 'boot',
                    'type': 'PERSISTENT',
                    'boot': True,
                    'autoDelete': True,
                    'initializeParams': {
                        'sourceImage': ''.join([COMPUTE_URL_BASE, 'projects/',
                                                'debian-cloud', '/global/',
                                                'images/', 'family/', imageWeb])
                    }
                }],
                'metadata': {
                    'dependsOn': [fw_instance, db_instance],
                    'items': [{
                        'key': 'startup-script-url',
                        'value': ''.join(['gs://',scripts_bucket,'/',webserver_script])},
                        {'key': 'ssh-keys', 'value': sshkey},
                        {'key': 'serial-port-enable', 'value': '1'}]
                },
                'serviceAccounts': [{
                    'email': 'default',
                    'scopes': [
                        'https://www.googleapis.com/auth/cloud.useraccounts.readonly',
                        'https://www.googleapis.com/auth/devstorage.read_only',
                        'https://www.googleapis.com/auth/logging.write',
                        'https://www.googleapis.com/auth/monitoring.write',
                        'https://www.googleapis.com/auth/compute.readonly',
                    ]}
                ],
                'networkInterfaces': [{
                    'network': '$(ref.' + web_network + '.selfLink)',
                    'subnetwork': '$(ref.' + web_subnet + '.selfLink)',
                    'networkIP': web_server_ip
                }]
            }
        },
        {
            'name': web_network,
            'type': 'compute.v1.network',
            'properties': {
                'autoCreateSubnetworks': False,
            }
        },
        {
            'name': web_subnet,
            'type': 'compute.v1.subnetwork',
            'properties': {
                'ipCidrRange': web_subnet_ip,
                'region': region,
                'network': '$(ref.' + web_network + '.selfLink)',
            }
        },
        {
            'name': mgmt_network,
            'type': 'compute.v1.network',
            'properties': {
                'autoCreateSubnetworks': False,
            }
        },
        {
            'name': mgmt_subnet,
            'type': 'compute.v1.subnetwork',
            'properties': {
                'ipCidrRange': mgmt_subnet_ip,
                'region': region,
                'network': '$(ref.' + mgmt_network + '.selfLink)',
            }
        },
        {
            'name': public_network,
            'type': 'compute.v1.network',
            'properties': {
                'autoCreateSubnetworks': False,
            }
        },
        {
            'name': public_subnet,
            'type': 'compute.v1.subnetwork',
            'properties': {
                'ipCidrRange': public_subnet_ip,
                'region': region,
                'network': '$(ref.' + public_network + '.selfLink)',
            }
        },

        {
            'name': db_network,
            'type': 'compute.v1.network',
            'properties': {
                'autoCreateSubnetworks': False,

            }
        },
        {
            'name': db_subnet,
            'type': 'compute.v1.subnetwork',
            'properties': {
                'ipCidrRange': db_subnet_ip,
                'region': region,
                'network': '$(ref.' + db_network + '.selfLink)',
            }
        },
        {
            'metadata': {
                'dependsOn': [mgmt_network, db_network, web_network, public_network]
            },
            'name': mgmt_firewall,
            'type': 'compute.v1.firewall',
            'properties': {
                'region': region,
                'network': '$(ref.' + mgmt_network + '.selfLink)',
                'direction': 'INGRESS',
                'priority': 1000,
                'sourceRanges': ['0.0.0.0/0'],
                'allowed': [{
                    'IPProtocol': 'tcp',
                    'ports': [22, 443]
                }]
            }
        },
        {
            'metadata': {
                'dependsOn': [mgmt_network, db_network, web_network, public_network]
            },
            'name': public_firewall,
            'type': 'compute.v1.firewall',
            'properties': {
                'region': region,
                'network': '$(ref.' + public_network + '.selfLink)',
                'direction': 'INGRESS',
                'priority': 1000,
                'sourceRanges': ['0.0.0.0/0'],
                'allowed': [{
                    'IPProtocol': 'tcp',
                    'ports': [80, 221, 222]
                }]
            }
        },
        {
            'metadata': {
                'dependsOn': [mgmt_network, db_network, web_network, public_network]
            },
            'name': web_firewall,
            'type': 'compute.v1.firewall',
            'properties': {
                'region': region,
                'network': '$(ref.' + web_network + '.selfLink)',
                'direction': 'INGRESS',
                'priority': 1000,
                'sourceRanges': ['0.0.0.0/0'],
                'allowed': [{
                    'IPProtocol': 'tcp',
                }, {
                    'IPProtocol': 'udp',
                }, {
                    'IPProtocol': 'icmp'
                }]
            }
        },
        {
            'metadata': {
                'dependsOn': [mgmt_network, db_network, web_network, public_network]
            },
            'name': db_firewall,
            'type': 'compute.v1.firewall',
            'properties': {
                'region': region,
                'network': '$(ref.' + db_network + '.selfLink)',
                'direction': 'INGRESS',
                'priority': 1000,
                'sourceRanges': ['0.0.0.0/0'],
                'allowed': [{
                    'IPProtocol': 'tcp',
                }, {
                    'IPProtocol': 'udp',
                }, {
                    'IPProtocol': 'icmp'
                }]
            }
        },
        {
            'metadata': {
                'dependsOn': [mgmt_network, db_network, web_network, public_network]
            },
            'name': web_route,
            'type': 'compute.v1.route',
            'properties': {
                'priority': 100,
                'network': '$(ref.' + web_network + '.selfLink)',
                'destRange': '0.0.0.0/0',
                'nextHopIp': '$(ref.' + fw_instance + '.networkInterfaces[2].networkIP)'
            }
        },
        {
            'metadata': {
                'dependsOn': [mgmt_network, db_network, web_network, public_network]
            },
            'name': db_route,
            'type': 'compute.v1.route',
            'properties': {
                'priority': 100,
                'network': '$(ref.' + db_network + '.selfLink)',
                'destRange': '0.0.0.0/0',
                'nextHopIp': '$(ref.' + fw_instance + '.networkInterfaces[3].networkIP)'
            }
        }

    ]
    outputs.append({'name': 'Web-Server-PublicIP-Address',
                    'value': '$(ref.' + fw_instance + '.networkInterfaces[1].accessConfigs[0].natIP)'})
    outputs.append({'name': 'PANFirewall-PublicIP-Address',
                    'value': '$(ref.' + fw_instance + '.networkInterfaces[0].accessConfigs[0].natIP)'})

    return {'resources': resources, 'outputs': outputs}
